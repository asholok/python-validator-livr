
OBJECTS_LIST = (list, dict)
NUMBER_LIST = (int, float)
PRIMITIVE_LIST = NUMBER_LIST + (str, bool, unicode)
EMPTY_PRIMITIVE = lambda x: x == None or x == '' 

